<!DOCTYPE html>
<html lang="en">
<?php include("Admin/termed.php"); ?>
<head>
<title>Login | Page</title>
<link rel="shortcut icon" href="assets/img/icon.png" type="image/x-icon" />

<meta charset="utf-8" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />


<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
<link href="../../use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet" />

<link href="assets/css/black-dashboard69ea.css?v=1.1.2" rel="stylesheet" />
<link href="assets/demo/demod41d.css?" rel="stylesheet" />
<link href="assets/css/nucleo-icons.css" rel="stylesheet" />
<link href="../../cdn.jsdelivr.net/npm/%40sweetalert2/theme-dark%404/dark.css" rel="stylesheet" />

<link href="assets/font-awesome/css/fontawesome.css" rel="stylesheet" />
<link href="assets/font-awesome/css/brands.css" rel="stylesheet" />
<link href="assets/font-awesome/css/solid.css" rel="stylesheet" />
</head>
<body>
<div class="wrapper">
<div class="full-page">
<div class="main-panel">
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
<div class="container-fluid">
<div class="navbar-wrapper">
<a class="navbar-brand" href="#"><?php echo $name ?></a>
</div>
<div class="collapse navbar-collapse justify-content-end">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" href="create">
<i class="fa-solid fa-gear fa-spin"></i> Generator</a
                    >
</li>

</ul>
</div>
</div>
</nav>
<div class="content">
<div class="container">
<div class="row">
<div class="col-lg-10">
<div class="card mb-3">
<img class="card-img-top" src="assets/img/backgorund.gif" alt="Card image cap" />
<div class="card-body">
<h4 class="card-title">Login Page</h4>
<p class="card-text">
Login to controller
</p>
<p class="card-text">
<small class="text-muted">login with token for now</small
                        >
</p>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-10">
<div class="card">
<div class="card-body">
<form action="#" class="signin-form">
<div class="form-group mb-3">
<label class="label" for="Auth">Your Token</label>
<input type="text" id="Auth" class="form-control" placeholder="Token" required=""> </div>
<div class="form-group">
<button type="button" onclick="SignIn(this);" class="form-control btn btn-primary submit px-3">submit!</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="footer">
<div class="container-fluid">
<div class="copyright float-center">
&copy;
<script type="00c7202f225bc49d8462d56a-text/javascript">
                  document.write(new Date().getFullYear());
                </script>
, made with <i class="fa-solid fa-heart-pulse fa-bounce"></i> by
<a href target="_blank"><?php echo $name ?></a>
</div>

</div>
</footer>
</div>
</div>
</div>
<input name="challenge" id="challenge" value="WkVYeTdnQWhzdUFRWEx5cHR0T3dKUT09" type="hidden">
<input name="site_key" id="site_key" value="6LcODAEnAAAAAFU4LBp1yZ3Kgd8r3UIuX3_zBeX1" type="hidden">

<script src="../../www.google.com/recaptcha/apie9f3.js?render=6LcODAEnAAAAAFU4LBp1yZ3Kgd8r3UIuX3_zBeX1" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="assets/js/core/jquery.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="../../cdn.jsdelivr.net/npm/sweetalert2%4011/dist/sweetalert2.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="assets/js/plugins/perfect-scrollbar.jquery.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="assets/main.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE" type="00c7202f225bc49d8462d56a-text/javascript"></script>

<script src="assets/js/plugins/chartjs.min.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>

<script src="assets/js/plugins/bootstrap-notify.js" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="/controllerPages/apis/main.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="assets/js/black-dashboarde209.js?v=1.0.0" type="00c7202f225bc49d8462d56a-text/javascript"></script>
<script src="../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="00c7202f225bc49d8462d56a-|49" defer></script></body>
</html>
