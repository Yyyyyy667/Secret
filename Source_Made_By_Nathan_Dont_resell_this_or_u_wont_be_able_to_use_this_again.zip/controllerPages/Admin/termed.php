<?php 
$webhook = "WEBHOOK HERE";
$name = "NAME HERE"; 
$color = "00000";
$imgurl = "IMAGE HERE";
?>